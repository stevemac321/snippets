/**********************************************************
FILE NAME  	: hw_init.h
DESCRIPTION     : 
Copyright	: Magnum Energy, Inc.
		: 2013
		: All Rights Reserved
**********************************************************/
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HW_INIT_H
#define __HW_INIT_H



void Hw_init(void);

#endif /* __HW_INIT_H */