/*******************************************************************************
FILE NAME   : main.c
DESCRIPTION : Where all the magic begins.


Copyright   : David Allegre
	    : 2015
	    : All Rights Reserved
*******************************************************************************/
/* Includes ------------------------------------------------------------------*/
//#include "main.h"
#include "hw_init.h"
#include "nucleoboard.h"
#include "print.h"
#ifdef __cplusplus
        #include "shared_ptr.hpp"
#endif

/* Public variables ----------------------------------------------------------*/
__IO uint32_t timer;
PRINT_DEFINEBUFFER(); /* required for lightweight sprintf */
#define PORTA   0x40020000
#define BSRRL   0x18  
#define BSRRH   0x1A

#define PORTA_BSRRL  (PORTA + BSRRL)
#define PORTA_BSRRH  (PORTA + BSRRH)
        
#define INPUT_MASK 0x00002000
#define PORTC 0x40020800
#define IDR 0x10
#define PORTC_IDR (PORTC + IDR)
/* Private variables
 * ----------------------------------------------------------*/
char clr_scrn[] = {27, 91, 50, 74, 0}; // esc[2J
uint32_t count;

/* Private prototype ---------------------------------------------------------*/
void delay(uint32_t time);

#ifdef __cplusplus
extern "C" {
#endif
// TODO: Add a 'extern' to the assembly language function
void ioscan(void); // all functions are 'extern' implicitly.

#ifdef __cplusplus
}
#endif

void cpp_blink(void); 
//--------------------------------------//

/*******************************************************************************
Function Name   : main
Description     :
Parameters      :
Return value    :               */
void main()
{
        // I use clang-format Linux kernel style (K&R mostly) to format my code.
	// Initialize the hardware
	Hw_init();
	count = 0; // Zero out count
	//------------------------------------//
	PrintString(clr_scrn); /* Clear entire screen */
	// Change [My name] to your name      ////
	PrintString("[My name]'s Nucleo STM32F401 is ... alive!!!\n");
	RETAILMSG(1, ("Programming Assignment #1: Built %s %s.\r\n\r\n",
		      __DATE__, __TIME__));
	//------------------------------------//
        
	while (1) {
		/*
		 * Call an assembly function called ioscan that scans the i/o
		 * button,
		 * and turns on the LED.
		*/
#ifdef __cplusplus
                cpp_blink(); //cpp version
#else
                ioscan();  // assembly version
#endif
		//----------------------------------//
		delay(500);
		RETAILMSG(1, ("Tick #%d \r\n", count++));
	}
}

/*******************************************************************************
Function Name   : delay
Description     : Add a delay for timing perposes.
Parameters      : Time - In ms. 1 = .001 second
Return value    : None              */
void delay(uint32_t time)
{
	timer = time;
	while (timer) {
	}
}
/*******************************************************************************
Function Name   : SystemInit
Description     : Called by IAR's assembly startup file.
Parameters      :
Return value    :               */
void SystemInit(void)
{
	// System init is called from the assembly .s file
	// We will configure the clocks in hw_init
	asm("nop");
}
#ifdef __cplusplus

void cpp_blink()
{
        stevemac::reg_ptr<uint32_t, PORTA_BSRRL> p;
        p.setval(0x20);
        delay(500);
        p.setval(0x20 << 16U);
        delay(500);
}
#endif

