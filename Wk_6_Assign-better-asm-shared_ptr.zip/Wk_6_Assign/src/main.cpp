/*******************************************************************************
FILE NAME   : main.c
DESCRIPTION : Where all the magic begins.


Copyright   : David Allegre
	    : 2015
	    : All Rights Reserved
*******************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "hw_init.h"
#include "nucleoboard.h"
#include "print.h"

/* Public variables ----------------------------------------------------------*/
__IO uint32_t timer;
PRINT_DEFINEBUFFER(); /* required for lightweight sprintf */

/* Private variables
 * ----------------------------------------------------------*/
char clr_scrn[] = {27, 91, 50, 74, 0}; // esc[2J
uint32_t count;

/* Private prototype ---------------------------------------------------------*/
void delay(uint32_t time);


// TODO: Add a 'extern' to the assembly language function
void ioscan(void); // all functions are 'extern' implicitly.
void c_ioscan(void); // c version
//--------------------------------------//

/*******************************************************************************
Function Name   : main
Description     :
Parameters      :
Return value    :               */
void main()
{
        // I use clang-format Linux kernel style (K&R mostly) to format my code.
	// Initialize the hardware
	Hw_init();
	count = 0; // Zero out count
	//------------------------------------//
	PrintString(clr_scrn); /* Clear entire screen */
	// Change [My name] to your name      ////
	PrintString("[My name]'s Nucleo STM32F401 is ... alive!!!\n");
	RETAILMSG(1, ("Programming Assignment #1: Built %s %s.\r\n\r\n",
		      __DATE__, __TIME__));
	//------------------------------------//
	while (1) {
		/*
		 * Call an assembly function called ioscan that scans the i/o
		 * button,
		 * and turns on the LED.
		*/
		ioscan();

		//----------------------------------//
		delay(500);
		RETAILMSG(1, ("Tick #%d \r\n", count++));
	}
}

/*******************************************************************************
Function Name   : delay
Description     : Add a delay for timing perposes.
Parameters      : Time - In ms. 1 = .001 second
Return value    : None              */
void delay(uint32_t time)
{

	timer = time;
	while (timer) {
	}
}
/*******************************************************************************
Function Name   : SystemInit
Description     : Called by IAR's assembly startup file.
Parameters      :
Return value    :               */
void SystemInit(void)
{
	// System init is called from the assembly .s file
	// We will configure the clocks in hw_init
	asm("nop");
}



#if 0
PORTA           equ 0x40020000
PORTC           equ 0x40020800    

// These are the registers in the GPIO that we will be dealing with
// Find the offsets from the base address in the reference manual.
IDR             equ   0x10  
BSRR            equ   0x18  

PORTA_BSRR      equ     PORTA + BSRR    ;; This is the address for BSRR on PORTA
PORTC_IDR       equ     PORTC + IDR     ;; This is the address for Input register, on PORTC

INPUT_MASK      equ     0x00002000
LED_ON_MASK     equ     0x00000020
LED_OFF_MASK    equ     0x00000000
#endif