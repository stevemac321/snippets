/**********************************************************
FILE NAME  	: hw_init.h
DESCRIPTION     : 
Copyright	: Magnum Energy, Inc.
		: 2013
		: All Rights Reserved
**********************************************************/
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HW_INIT_H
#define __HW_INIT_H

#ifdef __cplusplus
extern "C" {
#endif

void Hw_init(void);

#ifdef __cplusplus
}
#endif
#endif /* __HW_INIT_H */